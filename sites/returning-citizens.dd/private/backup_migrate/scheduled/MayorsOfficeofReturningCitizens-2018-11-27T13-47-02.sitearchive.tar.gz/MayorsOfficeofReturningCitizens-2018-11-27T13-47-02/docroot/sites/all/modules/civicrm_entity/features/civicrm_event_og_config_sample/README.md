civicrm_entity
==============

Demo feature using civicrm_entity - showing creating an OG when a CiviCRM Event of type
1 (by default Conference) is created.
 
 