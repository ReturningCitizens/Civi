CiviCRM Entity
==============

This module is available from [Drupal.org Contrib](https://drupal.org/project/civicrm_entity)

This module is intended to expose CiviCRM as an entity within Drupal to allow 
rules integration, entity references, node to civi-views etc.

## Documentation

See the [CiviCRM Entity handbook page on Drupal.org](https://www.drupal.org/node/2506765) for 
documentation.
